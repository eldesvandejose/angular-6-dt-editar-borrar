import { Component, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CheckAdminService } from '../../services/check-admin.service';

@Component({
  selector: 'a6b-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  /* Leemos la URL base de las API's a partir del archivo de configuración.
  La hacemos pública para poder leerla desde el FormComponent para seleccionar
  una imagen que mostrar en el formulario. */
  private URL = environment.APIS_URL;

  public login: string;
  public password: string;
  public errorEnDatos = false;
  public errorEnProceso = false;

  constructor(
    private http: HttpClient,
    private router: Router,
    private checkAdmin: CheckAdminService
  ) {
    this.login = '';
    this.password = '';
  }

  ngOnInit() {
    $(document).prop('title', 'Acceso de administrador');
    this.checkAdmin.checkToken();
    if (localStorage.getItem('token') != null) {
      this.router.navigateByUrl('');
    }
  }

  public tryLogin() {
    this.checkAdmin$().subscribe(
      this.accessSuccess.bind(this),
      this.accessError.bind(this)
    );
  }

  private checkAdmin$(): Observable<any> {
    return this.http.get(
      this.URL +
        'autenticacion/access_admin.php?login=' +
        this.login +
        '&pass=' +
        this.password
    );
  }

  private accessSuccess(result) {
    if (result.correcto === 'S') {
      localStorage.setItem('token', result.token);
      this.router.navigateByUrl('');
    } else {
      this.errorEnDatos = true;
    }
  }

  private accessError() {
    this.errorEnProceso = true;
  }

  public clearAlert() {
    this.errorEnDatos = false;
    this.errorEnProceso = false;
  }
}
