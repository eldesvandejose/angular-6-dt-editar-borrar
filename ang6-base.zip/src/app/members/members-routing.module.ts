import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MembersListComponent } from './members-list/members-list.component';
import { MemberFormComponent } from './member-form/member-form.component';

const routes: Routes = [
  {
    path: '',
    component: MembersListComponent
  },
  {
    path: 'form',
    component: MemberFormComponent
  },
  {
    path: 'form/:id',
    component: MemberFormComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MembersRoutingModule { }
