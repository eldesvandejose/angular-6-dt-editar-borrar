import { TestBed, inject } from '@angular/core/testing';

import { CheckAdminService } from './check-admin.service';

describe('CheckAdminService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CheckAdminService]
    });
  });

  it('should be created', inject([CheckAdminService], (service: CheckAdminService) => {
    expect(service).toBeTruthy();
  }));
});
