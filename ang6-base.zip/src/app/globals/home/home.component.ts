import { Component, OnInit } from '@angular/core';
import { CheckAdminService } from '../../services/check-admin.service';

@Component({
  selector: 'a6b-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private checkAdmin: CheckAdminService) { }

  ngOnInit() {
    $(document).prop('title', 'Inicio');
    this.checkAdmin.checkToken();
  }
}
