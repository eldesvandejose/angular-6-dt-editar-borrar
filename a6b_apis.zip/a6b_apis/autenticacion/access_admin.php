<?php
    include ('../db_conn.php');
    require_once './vendor/autoload.php';

    use Firebase\JWT\JWT;

    $currentTime = time();
    $limitTime = $currentTime + 86400; // Duración del token: 24 horas
    $privateKey = 'XAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9';

    /**
     * Recuperamos los datos enviados desde el formulario de acceso.
     */
    $login = $_GET["login"];
    $pass = $_GET["pass"];

    /**
     * Leemos la pass de la BD, si existe el admin
     */
    $consulta = "SELECT ";
    $consulta .= "login, ";
    $consulta .= "password, ";
    $consulta .= "nombre, ";
    $consulta .= "role ";
    $consulta .= "FROM admins ";
    $consulta .= "WHERE ";
    $consulta .= "login = '".$login."';";
    $hacerConsulta = $conexion->query($consulta);
    $datosDeAdmin = $hacerConsulta->fetch(PDO::FETCH_ASSOC);
    $hacerConsulta->closeCursor();

    /**
     * Lo primero es determinar si se ha encontrado el administrador.
     * Si no se encuentra, ya no se verifica más. Se devuelve una estructura 
     * sin datos y punto.
     * Si se encuentra, se comprueba si la password es correcta.
     * Si no lo es, se devuelve una estructura sin datos.
     * Si lo es, se construye el token, y se 
     * monta la estuctura que se devuelve operativa.
     */
    if ($datosDeAdmin === false) {
        $datosDeRetorno =  [
            'correcto' => "N"
        ];
    } else {
        if (password_verify($pass, $datosDeAdmin["password"]) === false) {
            $datosDeRetorno =  [
                'correcto' => "N"
            ];
        } else {
            /**
             * El admin ha sido correctamente autenticado. Vamos a modificar la matriz de sus datos,
             * de modo que pasemos la clave original. De este modo, cada vez que comprobemos el 
             * token, verificaremos la clave, y determinaremos si el token no ha sido manipulado, 
             * lo que añade un extra de seguridad adicional.
             */
            $datosDeAdmin["password"] = $pass; // La pass que se pasó en el acceso.
            $tokenContent = [
                'iat' => $currentTime, // Momento en que se inicia el token
                'exp' => $limitTime, // El token dura 24 horas.
                'userData' => $datosDeAdmin // información del usuario
            ];
            $tokenJWT = JWT::encode($tokenContent, $privateKey);
            $datosDeRetorno = [
                "correcto"=>"S",
                "token"=>$tokenJWT
            ];
        }
    }

    $datosDeRetorno = json_encode($datosDeRetorno);
    echo $datosDeRetorno;
?>

