<?php
  include_once ('db_conn.php');
 
  $requestData = json_decode(file_get_contents("php://input"), true);
  $id = $requestData["id"];
  $doi = $requestData["doi"];
  
  /* Determinamos si el doi ya existe (en un alta nueva) 
  o si ya existe con otro usuario (en una edición). */
  $consulta = "SELECT COUNT(*) FROM socios ";
  $consulta .= "WHERE doi = '".$doi."' ";
  if ($id != '0') $consulta .= "AND id != '".$id."' ";
  $hacerConsulta = $conexion->query($consulta);
  $duplicado = ($hacerConsulta->fetch(PDO::FETCH_ASSOC)["COUNT(*)"] != '0') ? "S" : "N";
  $hacerConsulta->closeCursor();
  
  echo $duplicado;
?>
